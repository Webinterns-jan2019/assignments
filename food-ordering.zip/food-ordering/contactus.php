<?php
require 'connection.php';
$conn = Connect();
$name = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$number = $conn->real_escape_string($_POST['number']);
$query = "INSERT INTO contact(name,email,number) VALUES('" . $name . "','" . $email . "','" . $number . "')";
$success = $conn->query($query);
if ($success==1)
{
    echo "<script type='text/javascript'>alert('success'); window.location='first.php' </script>";

    //header("location:index.php");
}
else
{
    echo "<script type='text/javascript'>alert('failed to save data');</script>";
    echo "<script type='text/javascript'>alert('try again');</script>";

}
?>